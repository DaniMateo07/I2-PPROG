/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#include "die.h"

int main(){

  Die *dado;
  int num;
  STATUS st=ERROR;

  dado = die_create(1);
  if(dado==NULL){
   return 0;
  }

  num = die_roll(dado);
  fprintf(stdout, "%d\n", num);

  st = die_print(stdout, dado);
  if(st==ERROR){
   die_destroy(dado);
   return 0;
  }  

  die_destroy(dado); 
 
  return 0;
}
