/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#include <stdlib.h>
#include "set.h"

#define MAX_DATOS 100

struct _Set{
  Id datos[MAX_DATOS];
  int num_datos;
};

Set *set_create(){

  Set *newSet=NULL; 
  int i=0;

  newSet = (Set*)malloc(sizeof(Set));

  for(i=0;i<MAX_DATOS;i++){
   newSet->datos[i] = NO_ID;
  }

  newSet->num_datos = 0;

  return newSet;
}

STATUS set_destroy(Set *s){

  if(s==NULL){
   return ERROR;
  }

  free(s);

  return OK;
}

STATUS set_add(Set *s, const Id id){

  if(s==NULL || id==NO_ID){
   return ERROR;
  }

  s->datos[s->num_datos] = id;

  s->num_datos++;
 
  return OK;
}

STATUS set_del(Set *s, const Id id){

  Id aux=NO_ID;
  int i=0;

  if(s==NULL){
   return ERROR;
  }
  
  for(i=0;i<MAX_DATOS;i++){
   if(s->datos[i]==id){
    s->datos[i] = NO_ID;
   }
  }
  
  for(i=0;i<s->num_datos;i++){
   if(s->datos[i]==NO_ID && i!=MAX_DATOS-1){
    aux=s->datos[i];
    s->datos[i]=s->datos[i+1];
    s->datos[i+1]=aux;
   }
  }

  s->num_datos--;

  return OK;
}

STATUS set_print(FILE *f, Set *s){

  int i=0;

  if(f==NULL || s==NULL){
   return ERROR;
  }

  for(i=0;i<s->num_datos;i++){
   fprintf(f, "%ld\n", s->datos[i]);
  }

  return OK;
}

int set_get_num(Set *s){
 
  if(s==NULL){
   return 0;
  }

  return s->num_datos;
}

Id set_get_object(Set *s, int indice){

  if(s==NULL){
   return -1;
  }

  return s->datos[indice];
}
