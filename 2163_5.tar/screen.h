/** 
 * @brief It defines a screen
 * 
 * @file screen.h
 * @author Profesores PPROG
 * @version 1.0 
 * @date 11-01-2017
 * @copyright GNU Public License
 *Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
 */

#ifndef __SCREEN__
#define __SCREEN__

#define SCREEN_MAX_STR 80

/* 
   Estructura _Area de tipo Area.
*/
typedef struct _Area Area;

/*
   Función que reserva memoria y crea el background.
   Lee:-
   Devuelve:-  
*/
void screen_init();

/*
   Función que libera la memoria del background.
   Lee:-
   Devuelve:-  
*/
void screen_destroy();

/*
   Función que rellena el background y el foreground con un color. 
   Lee:-
   Devuelve:-  
*/
void screen_paint();

/*
   Función que imprime por pantalla el prompt.
   Lee: Un puntero a una cadena de caracteres.
   Devuelve:-  
*/
void screen_gets(char *str);


/*
   Función que reserva memoria para la estructura _Area, guarda los valores leídos en ella y crea el área que va a ser utilizada en la  
   pantalla. 
   Lee: Valores de tipo int(enteros).
   Devuelve: Puntero a estructura de tipo Area.  
*/
Area* screen_area_init(int x, int y, int width, int height);

/*
   Función que libera la memoria reservada para la estructura _Area.
   Lee: Puntero a estructura de tipo Area.
   Devuelve:-  
*/
void screen_area_destroy(Area* area);

/*
   Función que limpia el background. 
   Lee: Puntero a estructura de tipo Area.
   Devuelve:-  
*/
void screen_area_clear(Area* area);

/*
   Función que resetea la posición del cursor.
   Lee: Puntero a estructura de tipo Area.
   Devuelve:-  
*/
void screen_area_reset_cursor(Area* area); 

/*
   Función que 
   Lee: Puntero a estructura de tipo Area y un puntero a una cadena de caracteres.
   Devuelve:-  
*/
void screen_area_puts(Area* area, char *str);

#endif
