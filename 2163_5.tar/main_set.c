/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#include "set.h"

int main(){

  Set *s=NULL;
  Id x, y, z;
  STATUS st=ERROR;

  fprintf(stdout, "Introduce tres números a guardar: \n");
  scanf("%ld", &x);
  scanf("%ld", &y);
  scanf("%ld", &z);

  s = set_create();
  if(s==NULL){
   fprintf(stdout, "Error.\n");
   return 0;
  }
  
  st = set_add(s, x);
  if(st==ERROR){
   set_destroy(s);
   return 0;
  }  

  st = set_add(s, y);
  if(st==ERROR){
   set_destroy(s);
   return 0;
  } 

  st = set_add(s, z);
  if(st==ERROR){
   set_destroy(s);
   return 0;
  } 

  fprintf(stdout, "\n");

  st = set_print(stdout, s);
  if(st==ERROR){
   set_destroy(s);
   return 0;
  } 

  fprintf(stdout, "\n");

  set_del(s, y);

  st = set_print(stdout, s);
  if(st==ERROR){
   set_destroy(s);
   return 0;
  }

  set_destroy(s); 
 
  return 0;
}
