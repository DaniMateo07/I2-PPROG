/** 
 * @brief It defines a space
 * 
 * @file space.h
 * @author Profesores PPROG
 * @version 1.0 
 * @date 13-01-2015
 * @copyright GNU Public License
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
 */

#ifndef SPACE_H
#define SPACE_H

#include "types.h"
#include "set.h"

/*
   Estructura _Space de tipo Space.
*/
typedef struct _Space Space;

#define MAX_SPACES 100
#define FIRST_SPACE 1

/* Información de cada función: */

/* 
   Función que reserva memoria para la estructura _Space y guarda los datos que se tienen en ella. 
   Lee: Valor de tipo Id.
   Devuelve: Puntero a estructura de tipo Space.
*/
Space* space_create(Id id);

/* 
   Función que libera la memoria que tiene la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_destroy(Space* space);

/* 
   Función que guarda el valor de tipo Id en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Valor de tipo Id.
*/
Id space_get_id(Space* space);

/* 
   Función que copia el valor del nombre guardado en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space y puntero a char.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_set_name(Space* space, char* name);

/* 
   Función que devuelve el valor del nombre guardado en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Puntero a variable de tipo char.
*/
const char* space_get_name(Space* space);

/* 
   Función que guarda la Id de north en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space y valor de tipo Id.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_set_north(Space* space, Id id);

/* 
   Función que devuelve la Id de north guardada en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Valor de tipo Id.
*/
Id space_get_north(Space* space);

/* 
   Función que guarda la Id de south en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space y valor de tipo Id.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_set_south(Space* space, Id id);

/* 
   Función que devuelve la Id de south guardada en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Valor de tipo Id.
*/
Id space_get_south(Space* space);

/* 
   Función que guarda la Id de east en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space y valor de tipo Id.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_set_east(Space* space, Id id);

/* 
   Función que devuelve la Id de east guardada en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Valor de tipo Id.
*/
Id space_get_east(Space* space);

/* 
   Función que guarda la Id de west en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space y valor de tipo Id.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_set_west(Space* space, Id id);

/* 
   Función que devuelve la Id de west guardada en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Valor de tipo Id.
*/
Id space_get_west(Space* space);

/* 
   Función que guarda el valor de object en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space y valor de tipo BOOL.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_set_objects(Space* space, Set *objects);

/* 
   Función que devuelve el valor de object guardado en la estructura _Space. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Puntero a estructura de tipo Set..
*/
Set *space_get_objects(Space* space);

/* 
   Función que imprime por pantalla el Id de las distintas direcciones y el objeto. 
   Lee: Puntero a estructura de tipo Space.
   Devuelve: Valor de tipo STATUS.
*/
STATUS space_print(Space* space);

#endif
