/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#ifndef OBJECT_H
#define OBJECT_H

#include "types.h"


/* Estructura _Object de tipo Object. */
typedef struct _Object Object;

/*
   Función que reserva memoria para un objeto y guarda sus datos en la estructura _Object. 
   Lee: Valor de tipo Id.
   Devuelve: Puntero a estructura de tipo Object.
*/
Object* object_create(Id Id);

/*
   Función que libera la memoria reservada en la estructura _Object para un objeto. 
   Lee: Puntero a estructura de tipo Object.
   Devuelve: Valor de tipo STATUS.  
*/
STATUS object_destroy(Object* object);

/*
   Función que devuelve la Id de un objeto.  
   Lee: Puntero a estructura de tipo Object.
   Devuelve: Valor de tipo Id.  
*/
Id object_get_id(Object* object);

/*
   Función que devuelve el nombre de un objeto. 
   Lee: Puntero a estructura de tipo Object.
   Devuelve: Puntero a cadena de caracteres. 
*/
const char* object_get_name(Object* object);

/*
   Función que modifica la Id de un objeto.  
   Lee: Puntero a estructura de tipo Object y un valor de tipo Id.
   Devuelve: Valor de tipo STATUS. 
*/
STATUS object_set_id(Object* object, Id Id);

/*
   Función que modifica el nombre de un objeto. 
   Lee: Puntero a estructura de tipo Object y un puntero a cadena de caracteres.
   Devuelve: Valor de tipo STATUS. 
*/
STATUS object_set_name(Object* object, char* name);

/*
   Función que imprime los datos de un objeto. 
   Lee: Puntero a estructura de tipo Object.
   Devuelve: Valor de tipo STATUS.  
*/
STATUS object_print(Object* object);

#endif 

