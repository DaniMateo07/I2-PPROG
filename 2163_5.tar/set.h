/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#ifndef SET_H
#define SET_H

#include <stdio.h>
#include "types.h"


/* 
  Estructura _Set de tipo Set. 
*/
typedef struct _Set Set;

/*
  Función que crea un conjunto reservando memoria para su estructura _Set.
  Lee: -.
  Devuelve: Puntero a estructura de tipo Set.
*/
Set *set_create();

/*
  Función que destruye un conjunto liberando la memoria reservada en su estructura _Set.
  Lee: Puntero a estructura de tipo Set.
  Devuelve: Valor de tipo STATUS.
*/
STATUS set_destroy(Set *s);

/*
  Función que añade un valor al conjunto.
  Lee: Puntero a estructura de tipo Set y un valor de tipo Id.
  Devuelve: Valor de tipo STATUS.
*/
STATUS set_add(Set *s, const Id id);

/*
  Función que elimina un valor del conjunto.
  Lee: Puntero a estructura de tipo Set y valor de tipo Id.
  Devuelve: Valor de tipo STATUS.
*/
STATUS set_del(Set *s, const Id id);

/*
  Función que imprime los valores en el conjunto en un fichero.
  Lee: Puntero a FILE y puntero a estructura de tipo Set.
  Devuelve: Valor de tipo STATUS.
*/
STATUS set_print(FILE *f, Set *s);

/*
  Función que devuelve el número de objetos de un conjunto.
  Lee: Puntero a estructura de tipo Set.
  Devuelve: Valor de tipo entero.
*/
int set_get_num(Set *s);

/*
  Función que devuelve el Id de un objeto del array de objetos de un conjunto.
  Lee: Puntero a estructura de tipo Set y valor de tipo entero.
  Devuelve: Valor de tipo Id.
*/
Id set_get_object(Set *s, int indice);

#endif /* SET_H */
