/** 
 * @brief It defines the game interface
 * for each command
 * 
 * @file game.h
 * @author Profesores PPROG
 * @version 1.0 
 * @date 13-01-2015 
 * @copyright GNU Public License
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
 */

#ifndef GAME_H
#define GAME_H

#include "command.h"
#include "space.h"
#include "object.h"
#include "player.h"
#include "die.h"

#define MAX_OBJ 30

/*
   Estructura _Game de tipo Game.
*/
typedef struct _Game{
  Player* player_location;
  Object* object_location[MAX_OBJ];
  Die *dado;
  Space* spaces[MAX_SPACES + 1];
  T_Command last_cmd;
} Game;

/*
   Función que crea el juego, inicializa los espacios y reserva memoria para los jugadores y los objetos.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: Valor de tipo STATUS.
*/
STATUS game_create(Game* game);

/*
   Función que actualiza el juego.
   Lee: Puntero a estructura de tipo Game y valor de tipo T_Command.
   Devuelve: Valor de tipo STATUS.
*/
STATUS game_update(Game* game, T_Command cmd);

/*
   Función que libera la memoria de los espacios del juego.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: Valor de tipo STATUS. 
*/
STATUS game_destroy(Game* game);

/*
   Función que -. 
   Lee: Puntero a estructura de tipo Game.
   Devuelve: Valor de tipo BOOL.  
*/
BOOL game_is_over(Game* game);

/*
   Función que -.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: -.
*/
void game_print_screen(Game* game);

/*
   Función que imprime los ids del objeto y del jugador, y los espacios.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: -.  
*/
void game_print_data(Game* game);

/*
   Función que devuelve un espacio.
   Lee: Puntero a estructura de tipo Game y un valor de tipo Id.
   Devuelve: Puntero a estructura de tipo Space.
*/
Space* game_get_space(Game* game, Id id);

/*
   Función que devuelve la id del espacio en el que se encuentra el jugador.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: Valor de tipo Id.
*/
Id game_get_player_location(Game* game);

/*
   Función que devuelve la id del espacio en el que se encuentra el objeto.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: Valor de tipo Id.
*/
Id game_get_object_location(Game* game);

/*
   Función que devuelve el último comando realizado.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: Valor de tipo T_Command. 
*/
T_Command game_get_last_command(Game* game);

/*
   Función que devuelve el id del espacio.
   Lee: Puntero a estructura de tipo Game y un valor de tipo entero.
   Devuelve: Valor de tipo Id. 
*/
Id game_get_space_id_at(Game* game, int position);

/*
   Función que añade un espacio al juego.
   Lee: Puntero a estructura de tipo Game.
   Devuelve: Valor de tipo STATUS.
*/
STATUS game_add_space(Game* game, Space* space);
/*

   Función que devuelve la Id de la localización del objeto.
   Lee: Puntero a estructura de tipo Game y un valor de tipo Id.
   Devuelve: Valor de tipo STATUS. 
*/
STATUS game_set_object_location(Game* game, Id id);

/*
   Función que devuelve la Id de la localización del jugador.
   Lee: Puntero a estructura de tipo Game y un valor de tipo Id.
   Devuelve: Valor de tipo STATUS. 
*/
STATUS game_set_player_location(Game* game, Id id);

#endif
