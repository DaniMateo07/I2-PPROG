/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#include <time.h>
#include <stdlib.h>
#include "die.h"

struct _Die{
  Id id;
  int last_num;
};

Die *die_create(Id id){

  Die *newDado=NULL;

  if(id==NO_ID){
   return NULL;
  }

  newDado = (Die*)malloc(sizeof(Die));

  if(newDado==NULL){
   return NULL;
  }

  newDado->id = id;

  newDado->last_num = 0;

  return newDado;
}

STATUS die_destroy(Die *d){

  if(d==NULL){
   return ERROR;
  }

  free(d);
  
  return OK;
}

int die_roll(Die *d){

  int dado;

  if(d==NULL){
   return 0;
  }

  srand(time(NULL)); /* Actualiza la semilla según la hora. */

  dado = rand() %6 + 1; /* Genera número aleatorio del 1 al 6. */

  d->last_num = dado;

  return dado;
}

STATUS die_print(FILE *f, Die *d){

  if(f==NULL || d==NULL){
   return ERROR;
  }

  fprintf(f, "Id dado->%ld\nÚltimo número sacado->%d\n", d->id, d->last_num);

  return OK;
}

int die_get(Die *d){

  if(d==NULL){
   return 0;
  }

  return d->last_num;
}
