/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#ifndef GAME_READER_H 
#define GAME_READER_H

/*
   Función que lee el archivo proporcionado como tablero, lo interpreta y guarda los datos en la estructura _Space.
   Lee: Puntero a estructura de tipo Game y un puntero a cadena de caracteres(nombre fichero tablero a leer).
   Devuelve: Valor de tipo STATUS. 
*/
STATUS game_load_spaces(Game* game, char* filename);

/*
   Función que comprueba si se ha leído bien el tablero y cargado su espacio e inicializa al jugador y al objeto.
   Lee: Puntero a estructura de tipo Game y un puntero a cadena de caracteres(fichero tablero).
   Devuelve: Valor de tipo STATUS. 
*/
STATUS game_create_from_file(Game* game, char* filename);

#endif
