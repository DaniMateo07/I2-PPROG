/** 
 * @brief It implements the command interpreter
 * 
 * @file command.h
 * @author Profesores PPROG
 * @version 1.0 
 * @date 19-12-2014 
 * @copyright GNU Public License
 *Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
 */

#ifndef COMMAND_H
#define COMMAND_H

/*
   Enumeración enum_Command de tipo T_Command.
*/

typedef enum enum_Command {
  NO_CMD = -1, 
  UNKNOWN, 
  EXIT, 
  FOLLOWING, 
  PREVIOUS, 
  TAKE,
  GRASP,
  LEFT,
  RIGHT,
  DIE} T_Command;

/*
   Función que lee los comandos introducidos.
   Lee: -
   Devuelve: Valor de tipo T_Command.
*/
T_Command get_user_input();

#endif
