/** 
 * @brief It implements the game interface and all the associated callbacks
 * for each command
 * 
 * @file game.c
 * @author Profesores PPROG
 * @version 1.0 
 * @date 13-01-2015 
 * @copyright GNU Public License
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López 
 * Pareja: 5
 * Grupo: 2163
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"
#include "game_reader.h"
#include "set.h"

#define N_CALLBACK 9

/**
   Define the function type for the callbacks
*/
typedef void (*callback_fn)(Game* game);

/**
   List of callbacks for each command in the game 
*/
void game_callback_unknown(Game* game);
void game_callback_exit(Game* game);
void game_callback_following(Game* game);
void game_callback_previous(Game* game);
void game_callback_take(Game* game);
void game_callback_grasp(Game* game);
void game_callback_left(Game *game);
void game_callback_right(Game *game);
void game_callback_die(Game *game);

static callback_fn game_callback_fn_list[N_CALLBACK]={
  game_callback_unknown,
  game_callback_exit,
  game_callback_following,
  game_callback_previous,
  game_callback_take,
  game_callback_grasp,
  game_callback_left,
  game_callback_right,
  game_callback_die};

/**
   Game interface implementation
*/

STATUS game_create(Game* game) {
  int i;
  
  for (i = 0; i < MAX_SPACES; i++) {
    game->spaces[i] = NULL;
  }

  for(i=0;i<4;i++){
  game->object_location[i] = object_create(i+1); 
  }

  game->player_location = player_create(1);

  game->dado = die_create(1);

  game->last_cmd = NO_CMD;
  
  return OK;
}

STATUS game_destroy(Game* game) {
  int i = 0;

  for (i = 0; (i < MAX_SPACES) && (game->spaces[i] != NULL); i++) {
    space_destroy(game->spaces[i]);
  }
      
  player_destroy(game->player_location);

  for(i=0;i<4;i++){
   object_destroy(game->object_location[i]); 
  }

  die_destroy(game->dado);
  
  return OK;
}

Space* game_get_space(Game* game, Id id){
  int i = 0;

  if (id == NO_ID) {
    return NULL;
  }
    
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    if (id == space_get_id(game->spaces[i])){
      return game->spaces[i];
    }
  }
    
  return NULL;
}

Id game_get_player_location(Game* game) {

  if(game==NULL){
   return NO_ID;
  }

  return player_get_location(game->player_location);
}

Id game_get_object_location(Game* game, Id id) {
 
  int i=0, j=0;
  Id obj_id = NO_ID;
  Set *objetos=NULL;
  
  if(id==NO_ID || game==NULL){
   return NO_ID;
  }

  obj_id = id;  

  for (i=0;i<MAX_SPACES && game->spaces[i]!=NULL;i++){
   objetos=space_get_objects(game->spaces[i]);
   for(j=0;j<set_get_num(objetos);j++){
    if(obj_id == set_get_object(objetos, j)){
     return space_get_id(game->spaces[i]);
    }
   }
  }
  
  return NO_ID;
}

STATUS game_update(Game* game, T_Command cmd) {
  game->last_cmd = cmd;
  (*game_callback_fn_list[cmd])(game);
  return OK;
}

T_Command game_get_last_command(Game* game){
  return game->last_cmd;
}

void game_print_data(Game* game) {
  int i = 0;
  
  printf("\n\n-------------\n\n");
  
  printf("=> Spaces: \n");
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    space_print(game->spaces[i]);
  }
  
  printf("=> Object location: %d\n", (int) object_get_id(game->object_location));    
  printf("=> Player location: %d\n", (int) player_get_id(game->player_location));
  printf("prompt:> ");
}

BOOL game_is_over(Game* game) {
  return FALSE;
}

STATUS game_add_space(Game* game, Space* space) {
  int i = 0;

  if (space == NULL) {
    return ERROR;
  }

  while ( (i < MAX_SPACES) && (game->spaces[i] != NULL)){
    i++;
  }

  if (i >= MAX_SPACES) {
    return ERROR;
  }

  game->spaces[i] = space;

  return OK;
}

Id game_get_space_id_at(Game* game, int position) {

  if (position < 0 || position >= MAX_SPACES) {
    return NO_ID;
  }

 return space_get_id(game->spaces[position]);
}

STATUS game_set_object_location(Game* game, Id id) {

  int i=0;
  Id obj_id=NO_ID;

  if (id==NO_ID || game==NULL){
    return ERROR;
  }

  obj_id = object_get_id(game->object_location);

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++){
    if(id==space_get_id(game->spaces[i])){
     space_set_object(game->spaces[i], obj_id);
    }
  }

  return OK;
}

STATUS game_set_player_location(Game* game, Id id) {
    
  if (id==NO_ID || game==NULL){
    return ERROR;
  }

  player_set_location(game->player_location, id);

  return OK;
}

/**
   Callbacks implementation for each action 
*/

void game_callback_unknown(Game* game) {
}

void game_callback_exit(Game* game) {
}

void game_callback_following(Game* game) {
  int i = 0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  
  space_id = game_get_player_location(game);
  if (space_id == NO_ID) {
    return;
  }
  
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    current_id = space_get_id(game->spaces[i]);
    if (current_id == space_id) {
      current_id = space_get_south(game->spaces[i]);
      if (current_id != NO_ID) {
	game_set_player_location(game, current_id);
      }
      return;
    }
  }
}

void game_callback_previous(Game* game) {
  int i = 0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  
  space_id = game_get_player_location(game);
  
  if (NO_ID == space_id) {
    return;
  }
  
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    current_id = space_get_id(game->spaces[i]);
    if (current_id == space_id) {
      current_id = space_get_north(game->spaces[i]);
      if (current_id != NO_ID) {
	game_set_player_location(game, current_id);
      }
      return;
    }
  }
}

/* Función que realiza el comando de coger un objeto del espacio en el que te encuentras. */
void game_callback_take(Game* game){
 
  int i=0;
  Id space_id=NO_ID;
  Id current_id=NO_ID;

  space_id = game_get_player_location(game);

  if(game==NULL || space_id==NO_ID || player_get_object(game->player_location)!=NO_ID){
   return;
  }

  for (i=0; i<MAX_SPACES && game->spaces[i]!=NULL; i++){
   current_id = space_get_id(game->spaces[i]);
   if(current_id==space_id && space_get_object(game->spaces[i])!=NO_ID){
    player_set_object(game->player_location, space_get_object(game->spaces[i]));
    space_set_object(game->spaces[i], NO_ID);
    return;
   }
  } 
}

/* Función que realiza el comando de dejar un objeto en el espacio en el que te encuentras. */
void game_callback_grasp(Game* game){

  int i=0;
  Id space_id=NO_ID;
  Id current_id=NO_ID;

  space_id = game_get_player_location(game);

  if(game==NULL || space_id==NO_ID || player_get_object(game->player_location)==NO_ID){
   return;
  }

  for(i=0; i<MAX_SPACES && game->spaces[i]!=NULL; i++){
   current_id = space_get_id(game->spaces[i]);
   if(current_id==space_id && space_get_object(game->spaces[i])==NO_ID){
    space_set_object(game->spaces[i], player_get_object(game->player_location));
    player_set_object(game->player_location, NO_ID);
    return;
   }
  }
}

/* Función que realiza el comando de desplazar el jugador a la casilla situada a la derecha(puente, ocas). */
void game_callback_left(Game *game){

  int i = 0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;

  space_id = game_get_player_location(game);

  if(game==NULL || space_id==NO_ID){
   return;
  }

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
   current_id = space_get_id(game->spaces[i]);
   if (current_id == space_id) {
    current_id = space_get_west(game->spaces[i]);
     if (current_id != NO_ID) {
      game_set_player_location(game, current_id);
     }
     return;
   }
  }
}

/* Función que realiza el comando de desplazar el jugador a la casilla situada a la izquierda(puente, muerte, ocas). */
void game_callback_right(Game *game){

  int i = 0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;

  space_id = game_get_player_location(game);

  if(game==NULL || space_id==NO_ID){
   return;
  }

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
   current_id = space_get_id(game->spaces[i]);
   if (current_id == space_id) {
    current_id = space_get_east(game->spaces[i]);
     if (current_id != NO_ID) {
      game_set_player_location(game, current_id);
     }
     return;
   }
  }   
}

/* Función que realiza el comando de lanzar un dado. */
void game_callback_die(Game *game){

  int num=0;

  if(game==NULL){
   return;
  }

  num = die_roll(game->dado);

  if(num==0){
   return;
  }
}
