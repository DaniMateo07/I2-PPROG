/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "player.h"

struct _Player{
  Id id;
  char name[WORD_SIZE + 1];
  Id object;  
  Id location;
};

Player* player_create(Id Id){

  Player *newPlayer;

  if(Id==NO_ID){
   return NULL;
  }

  newPlayer = (Player*)malloc(sizeof(Player));

  if(newPlayer==NULL){
   return NULL;
  }

  newPlayer->id = Id;

  newPlayer->name[0] = '\0';

  newPlayer->object = NO_ID;

  newPlayer->location = NO_ID;

  return newPlayer;
}

STATUS player_destroy(Player* player){

  if(player==NULL){
   return ERROR;
  }

  free(player);

  player = NULL;

  return OK;
}

Id player_get_id(Player* player){
  
  if(player==NULL){
   return NO_ID;
  }

  return player->id;
}

const char* player_get_name(Player* player){

  if(player==NULL){
   return NULL;
  }

  return player->name;
}

Id player_get_location(Player* player){

  if(player==NULL){
   return NO_ID;
  }

  return player->location;
}

Id player_get_object(Player* player){

  if(player==NULL){
   return NO_ID;
  }
 
  return player->object;
} 

STATUS player_set_id(Player* player, Id Id){

  if(player==NULL || Id==NO_ID){
   return ERROR;
  }

  player->id = Id;

  return OK;
}

STATUS player_set_name(Player* player, char *name){

  if(player==NULL || name==NULL){
   return ERROR;
  }

  if (!strcpy(player->name, name)) {
    return ERROR;
  }

  return OK;
}

STATUS player_set_location(Player* player, Id location){

  if(player==NULL || location==NO_ID){
   return ERROR;
  }

  player->location = location;

  return OK;
}

STATUS player_set_object(Player* player, Id object){

  if(player==NULL){
   return ERROR;
  }

  player->object = object;

  return OK;
}

STATUS player_print(Player* player){

  Id idaux = NO_ID;

  if(player==NULL){
   return ERROR;
  }

  fprintf(stdout, "-->PLayer(Id: %ld; Name: %s)\n", player->id, player->name);

  idaux = player_get_location(player);
  if (NO_ID != idaux) {
    fprintf(stdout, "---> Location link: %ld.\n", idaux);
  } else {
    fprintf(stdout, "---> No location link.\n");
  }

  idaux = player_get_object(player);
  if (NO_ID != idaux) {
    fprintf(stdout, "---> Object with the player: %ld.\n", idaux);
  } else {
    fprintf(stdout, "---> No object with the player.\n");
  }

  return OK;
}

