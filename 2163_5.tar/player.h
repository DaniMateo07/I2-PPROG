/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#ifndef PLAYER_H
#define PLAYER_H

#include "types.h"

/* Estructura _Player de tipo Player. */
typedef struct _Player Player;

/*
   Función que reserva memoria para la estructura _Player y guarda los datos de un jugador en ella.
   Lee: Valor de tipo Id.
   Devuelve: Puntero a estructura de tipo Player.
*/
Player* player_create(Id Id);

/*
   Función que libera la memoria reservada en la estructura _Player para un jugador.
   Lee: Puntero a estructura de tipo Player.
   Devuelve: Valor de tipo STATUS.
*/
STATUS player_destroy(Player* player);

/*
   Función que devuelve el valor de la id de un jugador.
   Lee: Puntero a estructura de tipo Player.
   Devuelve: Valor de tipo Id.
*/
Id player_get_id(Player* player);

/*
   Función que devuelve el nombre de un jugador.
   Lee: Puntero a estructura de tipo Player.
   Devuelve: Puntero a cadena de caracteres.
*/
const char* player_get_name(Player* player);

/*
   Función que devuelve el id de la localización de un jugador.
   Lee: Puntero a estructura de tipo Player.
   Devuelve: Valor de tipo Id.
*/
Id player_get_location(Player* player);

/*
   Función que devuelve el id del objeto de un jugador.
   Lee: Puntero a estructura de tipo Player.
   Devuelve: Valor de tipo Id.
*/
Id player_get_object(Player* player);

/*
   Función que modifica el valor de la id de un jugador.
   Lee: Puntero a estructura de tipo Player y un valor de tipo Id.
   Devuelve: Valor de tipo STATUS.
*/
STATUS player_set_id(Player* player, Id Id);

/*
   Función que modifica el nombre de un jugador.
   Lee: Puntero a estructura de tipo Player y un puntero a cadena de caracteres.
   Devuelve: Valor de tipo STATUS.
*/
STATUS player_set_name(Player* player, char *name);

/*
   Función que modifica el id de la localización de un jugador.
   Lee: Puntero a estructura de tipo Player y un valor de tipo Id.
   Devuelve: Valor de tipo STATUS.
*/
STATUS player_set_location(Player* player, Id location);

/*
   Función que modifica el id del objeto de un jugador.
   Lee: Puntero a estructura de tipo Player y un valor de tipo Id.
   Devuelve: Valor de tipo STATUS.
*/
STATUS player_set_object(Player* player, Id object);

/*
   Función que imprime los datos de un jugador.
   Lee: Puntero a estructura de tipo Player.
   Devuelve: Valor de tipo STATUS.
*/
STATUS player_print(Player* player);

#endif 

