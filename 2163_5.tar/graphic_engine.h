/** 
 * @brief It defines a textual graphic engine
 * 
 * @file graphic_engine.h
 * @author Profesores PPROG
 * @version 1.0 
 * @date 18-01-2017
 * @copyright GNU Public License
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
 */

#ifndef __GRAPHIC_ENGINE__
#define __GRAPHIC_ENGINE__

#include "game.h"

/*
   Estructura _Graphic_engine de tipo Graphic_engine.
*/
typedef struct _Graphic_engine Graphic_engine;

/*
   Función que reserva memoria para cada parte visual de la pantalla.
   Lee:-
   Devuelve: Puntero a estructura de tipo Graphic_engine. 
*/
Graphic_engine* graphic_engine_create();

/*
   Función que libera la memoria de cada parte visual de la pantalla.
   Lee: Puntero a estructura de tipo Graphic_engine.
   Devuelve:-
*/
void graphic_engine_destroy(Graphic_engine *ge);

/*
   Función que imprime por pantalla los distintos espacios(casillas) del juego.
   Lee: Puntero a estructura de tipo Graphic_engine y puntero a estructura de tipo Game.
   Devuelve:-
*/
void graphic_engine_paint_game(Graphic_engine *ge, Game *game);

/*
   Función que escribe los comandos.
   Lee: Puntero a estructura de tipo Graphic_engine y un puntero a cadena de caracteres.
   Devuelve:-
*/
void graphic_engine_write_command(Graphic_engine *ge, char *str);

#endif
