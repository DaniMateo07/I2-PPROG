/**
 * @brief It defines common types
 *
 * @file types.h
 * @author Profesores PPROG
 * @version 1.0
 * @date 13-01-2015
 * @copyright GNU Public License
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
 */

#ifndef TYPES_H
#define TYPES_H

#define WORD_SIZE 1000
#define NO_ID -1

/* 
   Tipo long = Id.
*/
typedef long Id;

/* 
   Enumeración de tipo BOOL.
*/
typedef enum {
  FALSE, TRUE
} BOOL;

/* 
   Enumeración de tipo STATUS.
*/
typedef enum {
  ERROR, OK
} STATUS;

/* 
   Enumeración de tipo DIRECTION.
*/
typedef enum {
  N, S, E, W
} DIRECTION;

#endif
