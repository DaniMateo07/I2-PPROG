/* 
 * Alumnos: Daniel Mateo Moreno y Diego Troyano López
 * Pareja: 5
 * Grupo: 2163
*/

#ifndef DIE_H 
#define DIE_H

#include <stdio.h>
#include "types.h"

/*
  Estructura _Die de tipo Die.
*/
typedef struct _Die Die;

/*
  Función que crea un dado reservando memoria en su estructura _Die.
  Lee: Valor de tipo Id.
  Devuelve: Puntero a estructura de tipo Die.
*/
Die *die_create(Id id);

/*
  Función que destruye un dado liberando la memoria guardada en su estructura _Die.
  Lee: Puntero a estructura de tipo Die.
  Devuelve: Valor de tipo STATUS.
*/
STATUS die_destroy(Die *d);

/*
  Función que genera un número aleatorio(del 1 al 6) como un dado.
  Lee: Puntero a estructura de tipo Die.
  Devuelve: Valor de tipo entero.
*/
int die_roll(Die *d);

/*
  Función que imprime los datos del dado en un fichero.
  Lee: Puntero a FILE y puntero a estructura de tipo Die.
  Devuelve: Valor de tipo int.
*/
STATUS die_print(FILE *f, Die *d);

/*
  Función que devuelve el último número del dado generado.
  Lee: Puntero a estructura de tipo Die.
  Devuelve: Valor de tipo entero.
*/
int die_get(Die *d);


#endif /* DIE_H */
